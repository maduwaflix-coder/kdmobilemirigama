// Paste your Supabase values between the quotes (see README.txt)
window.SB={url:"",key:""};
