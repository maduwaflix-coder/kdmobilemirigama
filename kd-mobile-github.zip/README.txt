KD MOBILE - Netlify setup
=========================
Site eka dan Netlify ekata danna puluwan. Admin panel eken wenas kam save wenna (price, photos, sold...) free Supabase database ekak one. Eka eka parak set karanna.

1. supabase.com -> New project (Region: Singapore). Project hadenakan poddak inna.
2. SQL Editor -> New query -> supabase-setup.sql eke okkoma paste karala Run.
3. Authentication -> Users -> Add user -> Create new user:
      Email:    kdmobile@kdmobile.lk
      Password: (oya hithuwa password eka; meka GitHub ekata danna epa)
      "Auto Confirm User" tick karanna.
4. Authentication -> Sign In / Providers (or Settings) -> Email -> "Allow new users to sign up" OFF karanna.
5. Project Settings -> API: "Project URL" saha "anon public" key eka copy karala config.js ekata paste karanna.
6. GitHub: new PUBLIC repository -> files upload -> Settings > Pages > Deploy from branch (main, root).

Admin: https://USERNAME.github.io/REPO/#/admin
Username: KDMOBILE   Password: oya Supabase eke hadapu password eka

Photos Supabase Storage ("photos" bucket) ekata upload wenawa. WhatsApp number, phone, address, hours Admin > Website Settings eken wenas karanna.
