-- Run this once in Supabase: SQL Editor > New query > paste > Run
create table if not exists kv(key text primary key, value jsonb not null, updated_at timestamptz default now());
alter table kv enable row level security;
create policy "public read" on kv for select using (true);
create policy "admin insert" on kv for insert to authenticated with check ((auth.jwt()->>'email')='kdmobile@kdmobile.lk');
create policy "admin update" on kv for update to authenticated using ((auth.jwt()->>'email')='kdmobile@kdmobile.lk') with check ((auth.jwt()->>'email')='kdmobile@kdmobile.lk');
insert into storage.buckets(id,name,public) values('photos','photos',true) on conflict do nothing;
create policy "public read photos" on storage.objects for select using (bucket_id='photos');
create policy "admin upload photos" on storage.objects for insert to authenticated with check (bucket_id='photos' and (auth.jwt()->>'email')='kdmobile@kdmobile.lk');
create policy "admin delete photos" on storage.objects for delete to authenticated using (bucket_id='photos' and (auth.jwt()->>'email')='kdmobile@kdmobile.lk');
